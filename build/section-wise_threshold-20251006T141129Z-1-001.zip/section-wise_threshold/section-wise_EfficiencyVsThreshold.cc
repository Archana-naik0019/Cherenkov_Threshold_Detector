#include <TGraph.h>
#include <TCanvas.h>
#include <TLegend.h>
#include <TAxis.h>
#include <TStyle.h>

void plotFoldRatios() {
    // Number of data points
    const int N = 15;

    // Pressure (atm)
    double pressure[N] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};

    // 5-fold/4-fold (1PE)
    double ratio1PE[N] = {
        0.164037855, 0.105740181, 0.136986301, 0.106824926, 0.10031348,
        0.092342885, 0.084302326, 0.098802395, 0.072254335, 0.048710602,
        0.066997519, 0.047029703, 0.053097345, 0.049016808, 0.048387097
    };

    // 5-fold/4-fold (4PE)
    double ratio4PE[N] = {
        0.085173502, 0.036253776, 0.054794521, 0.041543027, 0.05015674,
        0.044858481, 0.026162791, 0.035928144, 0.037572254, 0.022926236,
        0.02776675, 0.027227723, 0.044247788, 0.016339869, 0.032258065
    };

    // Create graphs
    TGraph *g1 = new TGraph(N, pressure, ratio1PE);
    TGraph *g2 = new TGraph(N, pressure, ratio4PE);

    // Style
    gStyle->SetOptStat(0);

    g1->SetLineColor(kBlue);
    g1->SetLineWidth(2);
    g1->SetMarkerStyle(20);
    g1->SetMarkerColor(kBlue);

    g2->SetLineColor(kRed);
    g2->SetLineWidth(2);
    g2->SetMarkerStyle(21);
    g2->SetMarkerColor(kRed);

    // Canvas
    TCanvas *c1 = new TCanvas("c1", "5-fold / 4-fold Ratios vs Pressure", 800, 600);

    // Draw first graph
    g1->SetTitle("5-fold / 4-fold Ratios vs Pressure;Pressure (atm);Ratio");
    g1->Draw("APL");
    g1->GetXaxis()->SetLimits(0, 17);   // X-axis from 0 to 17 atm
    g1->GetYaxis()->SetRangeUser(0, 0.18);
    
    g2->Draw("PL SAME");

    // Legend
    TLegend *leg = new TLegend(0.15, 0.75, 0.45, 0.88);
    leg->AddEntry(g1, "5-fold/4-fold (1PE)", "lp");
    leg->AddEntry(g2, "5-fold/4-fold (4PE)", "lp");
    leg->Draw();

    c1->Update();
}

